# ASCEND Esports

ASCEND Esports için Standoff 2 takım sitesi. Kadro, maç sonuçları, turnuvalar ve takım istatistiklerinin yanında xASC klanı için başvuru formu ve yönetici paneli içerir.

## Özellikler

- ASCEND kadrosu, maç geçmişi, turnuvalar ve istatistikler
- xASC oyuncu başvuru formu
- Clerk ile korunan yönetici paneli
- Başvurular ve takım içerikleri için PostgreSQL veritabanı

## Teknoloji

- React, Vite ve TypeScript
- Express API
- PostgreSQL ve Drizzle ORM
- pnpm workspace monorepo

## Gereksinimler

- Node.js 24 veya üzeri
- pnpm 10.26.1
- Çalışan bir PostgreSQL veritabanı (uygulamayı çalıştırmak için)
- Yönetici girişi için Clerk yapılandırması

## Kurulum ve kontroller

```bash
pnpm install --frozen-lockfile
pnpm run typecheck
DATABASE_URL=postgresql://ci:ci@127.0.0.1:5432/ci pnpm --filter @workspace/api-server test
PORT=24611 BASE_PATH=/ pnpm run build
```

Test komutundaki `DATABASE_URL` yalnızca testlerin veritabanı bağlantı ayarını sağlaması içindir; gerçek veritabanı adresini bu örneğe yazmayın.

GitHub Actions, her push ve pull request'te tür denetimini, API testlerini ve üretim derlemesini çalıştırır.

## Ortam değişkenleri

`.env.example` gerekli değişken adlarını listeler. Gerçek değerleri bu dosyaya veya GitHub'a eklemeyin. Replit'te değerleri Secrets bölümünde; başka bir barındırma ortamında ise o ortamın güvenli değişken ayarlarında tanımlayın.

| Değişken | Kullanım |
| --- | --- |
| `DATABASE_URL` | PostgreSQL bağlantı adresi |
| `ASCEND_ADMIN_EMAIL` | Yönetim paneline erişebilecek hesap |
| `CLERK_PUBLISHABLE_KEY` | API tarafındaki Clerk yapılandırması |
| `CLERK_SECRET_KEY` | Clerk proxy için gizli anahtar |
| `VITE_CLERK_PUBLISHABLE_KEY` | Web uygulamasındaki Clerk yapılandırması |
| `VITE_CLERK_PROXY_URL` | İsteğe bağlı Clerk proxy adresi |
| `PORT`, `BASE_PATH` | Uygulama servislerinin portu ve taban yolu; Replit iş akışları bunları sağlar |

Yerel `.env` dosyaları Git tarafından yok sayılır. API servisi `.env` dosyasını kendiliğinden yüklemez; değişkenleri çalıştırma ortamında tanımlayın.

## GitHub ve yayınlama

GitHub bu projenin kaynak kodunu saklar; uygulamayı tek başına çalıştırıp yayınlamaz. Bu proje API, PostgreSQL ve Clerk kullandığı için GitHub Pages tek başına uygun değildir. Siteyi Replit'te veya web uygulamasıyla API'yi aynı `/api` yolunda yönlendirebilen başka bir barındırma ortamında çalıştırın.

Bu depoda henüz bir `LICENSE` dosyası yok. GitHub'da herkese açık görünmesi, başkalarına kodu yeniden kullanma izni verildiği anlamına gelmez.
